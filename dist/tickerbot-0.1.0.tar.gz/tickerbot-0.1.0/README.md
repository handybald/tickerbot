# Ticker Bot

A stock trading bot with suggestion and automatic modes.

## Features

- **Suggestion Mode**: Get trading suggestions for a stock based on technical indicators and news sentiment.
- **Automatic Mode**: Run the bot in automatic trading mode with configurable parameters.
- **Backtesting**: Backtest your trading strategies on historical data.

## Installation

```bash
pip install .
```

## Usage

```bash
tickerbot suggestion AAPL
tickerbot automatic --daily-limit 2000 --aggressiveness 0.7 --target-profit 150
tickerbot backtest rsi AAPL
```
